package com.journaldev.recyclerviewgridlayoutmanager;

/**
 * Created by anupamchugh on 11/02/17.
 */

public class DataModel {


    public String text;
    public int drawable;
    public String color;

    public DataModel(String t, int d, String c )
    {
        text=t;
        drawable=d;
        color=c;
    }
}
