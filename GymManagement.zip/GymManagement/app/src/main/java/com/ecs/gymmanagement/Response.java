package com.ecs.gymmanagement;

public class Response {

    private String message;
    private String path;

    public String getMessage() {
        return message;
    }

    public String getPath() {
        return path;
    }

}
